package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyecttap.ui.theme.ProyectTAPTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown

class Ejercicio4Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Ejercicio4Screen()
                }
            }
        }
    }
}

@Composable
fun Ejercicio4Screen() {
    val context = LocalContext.current
    val opciones = listOf("Rojo", "Verde", "Azul")
    var colorSeleccionado by remember { mutableStateOf("") }
    var mensaje by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ComboBox equivalente (DropdownMenu)
        Box {
            OutlinedTextField(
                value = colorSeleccionado,
                onValueChange = { colorSeleccionado = it },
                label = { Text("Selecciona un color") },
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                trailingIcon = {
                    IconButton(onClick = { expanded = !expanded }) {
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }
            )
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                opciones.forEach { color ->
                    DropdownMenuItem(
                        text = { Text(color) },
                        onClick = {
                            colorSeleccionado = color
                            mensaje = "El color elegido es $color"
                            expanded = false
                        }
                    )
                }
            }
        }

        // Resultado
        Text(
            text = mensaje,
            fontSize = 18.sp,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.Black)
                .padding(12.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}
