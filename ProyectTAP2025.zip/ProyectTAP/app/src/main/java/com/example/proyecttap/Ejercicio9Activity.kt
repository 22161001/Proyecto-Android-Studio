package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextAlign
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio9Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Ejercicio9Screen()
                }
            }
        }
    }
}

@Composable
fun Ejercicio9Screen() {
    val context = LocalContext.current
    // Estado para el valor del Spinner/NumberPicker
    var spinnerValue by remember { mutableStateOf(4) }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // NumberPicker personalizado (equivalente al JSpinner)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            // Botón para decrementar
            Button(
                onClick = { if (spinnerValue > 0) spinnerValue -= 2 },
                enabled = spinnerValue > 0,
                modifier = Modifier.size(48.dp)
            ) {
                Text("-")
            }

            // Valor actual
            Text(
                text = spinnerValue.toString(),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier
                    .width(80.dp)
                    .padding(horizontal = 16.dp),
                textAlign = TextAlign.Center
            )

            // Botón para incrementar
            Button(
                onClick = { if (spinnerValue < 10) spinnerValue += 2 },
                enabled = spinnerValue < 10,
                modifier = Modifier.size(48.dp)
            ) {
                Text("+")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Mostrar el valor actual (equivalente al JLabel)
        Text(
            text = "El valor es: $spinnerValue",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .wrapContentWidth(Alignment.CenterHorizontally)
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}