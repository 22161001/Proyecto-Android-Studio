package com.example.proyecttap

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class MenuActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MenuContent()
                }
            }
        }
    }

    @Composable
    fun MenuContent() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio1Activity::class.java))
            }) {
                Text("Ejercicio 1")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio2Activity::class.java))
            }) {
                Text("Ejercicio 2")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio3Activity::class.java))
            }) {
                Text("Ejercicio 3")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio4Activity::class.java))
            }) {
                Text("Ejercicio 4")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio5Activity::class.java))
            }) {
                Text("Ejercicio 5")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio6Activity::class.java))
            }) {
                Text("Ejercicio 6")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio7Activity::class.java))
            }) {
                Text("Ejercicio 7")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio8Activity::class.java))
            }) {
                Text("Ejercicio 8")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio9Activity::class.java))
            }) {
                Text("Ejercicio 9")
            }
            Button(onClick = {
                startActivity(Intent(this@MenuActivity, Ejercicio10Activity::class.java))
            }) {
                Text("Ejercicio 10")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Botón Cerrar sesión
            Button(
                onClick = {
                    val intent = Intent(this@MenuActivity, MainActivity::class.java)
                    startActivity(intent)
                    finish() // Finaliza MenuActivity para no poder regresar con botón atrás
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Cerrar sesión", color = MaterialTheme.colorScheme.onError)
            }

        }
    }
}
