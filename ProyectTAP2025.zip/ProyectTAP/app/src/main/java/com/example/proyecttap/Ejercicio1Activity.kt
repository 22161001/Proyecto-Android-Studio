package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.border
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio1Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Ejercicio1Screen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio1Screen() {
    val context = LocalContext.current
    var perroChecked by remember { mutableStateOf(false) }
    var gatoChecked by remember { mutableStateOf(false) }
    var ratonChecked by remember { mutableStateOf(false) }
    var resultado by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ejercicio 1") })
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Checkboxes
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(
                        checked = perroChecked,
                        onCheckedChange = { perroChecked = it }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Perro")
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(
                        checked = gatoChecked,
                        onCheckedChange = { gatoChecked = it }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Gato")
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(
                        checked = ratonChecked,
                        onCheckedChange = { ratonChecked = it }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Ratón")
                }

                // Botón
                Button(onClick = {
                    var mensaje = "Animales elegidos:"
                    if (perroChecked) mensaje += " Perro"
                    if (gatoChecked) mensaje += " Gato"
                    if (ratonChecked) mensaje += " Ratón"
                    resultado = mensaje
                }) {
                    Text("Aceptar")
                }

                // Texto resultado
                Text(
                    text = resultado,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                        .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        .padding(8.dp)
                )
                Button(
                    onClick = {
                        // Cierra esta actividad y regresa al menú
                        (context as? ComponentActivity)?.finish()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Regresar al menú")
                }
            }
        }
    )
}
