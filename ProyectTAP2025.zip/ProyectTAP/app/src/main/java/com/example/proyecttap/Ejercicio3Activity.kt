package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio3Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ContadorDeCoches()
                }
            }
        }
    }
}

@Composable
fun ContadorDeCoches() {
    val context = LocalContext.current

    var coches by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = { coches++ }) {
            Text("Entró un coche")
        }

        Button(onClick = {
            if (coches > 0) coches--
        }) {
            Text("Salió un coche")
        }

        Button(onClick = { coches = 0 }) {
            Text("Reiniciar")
        }

        Spacer(modifier = Modifier.height(40.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Coches en el Parking: ", style = MaterialTheme.typography.titleMedium)
            Text(
                text = "$coches",
                modifier = Modifier
                    .padding(start = 8.dp)
                    .border(1.dp, MaterialTheme.colorScheme.onSurface)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium
            )

        }
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}
