package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio5Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Ejercicio5Screen()
                }
            }
        }
    }
}

@Composable
fun Ejercicio5Screen() {
    val context = LocalContext.current
    var listaNombres by remember { mutableStateOf(listOf<String>()) }
    var resultado by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        // Lista de nombres en la parte superior
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            listaNombres.forEach { nombre ->
                Text(
                    text = nombre,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { resultado = nombre }
                        .padding(8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Texto del resultado (antes de los botones)
        Text(
            text = resultado,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),  // Espacio antes de los botones
            style = MaterialTheme.typography.bodyLarge
        )

        // Botones de acción en la parte inferior
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(onClick = {
                listaNombres = listOf("Juan", "María", "Luis")
            }) {
                Text("Curso 1")
            }

            Button(onClick = {
                listaNombres = listOf("Ana", "Marta", "Jose")
            }) {
                Text("Curso 2")
            }

            Button(onClick = {
                listaNombres = emptyList()
                resultado = ""
            }) {
                Text("Vaciar")
            }

        }
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}