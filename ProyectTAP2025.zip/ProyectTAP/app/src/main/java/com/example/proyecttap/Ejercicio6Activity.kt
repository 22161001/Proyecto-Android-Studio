package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.border
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio6Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Ejercicio6Screen()
                }
            }
        }
    }
}

@Composable
fun Ejercicio6Screen() {
    val context = LocalContext.current
    var listaNumeros by remember { mutableStateOf<List<String>>(emptyList()) }
    var resultado by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf("") }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {

        // Menú desplegable
        Box(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (selectedItem.isBlank()) "Selecciona un número" else selectedItem,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = true }
                    .padding(12.dp)
                    .border(1.dp, MaterialTheme.colorScheme.onSurface)
            )
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                listaNumeros.forEach { numero ->
                    DropdownMenuItem(
                        text = { Text(numero) },
                        onClick = {
                            selectedItem = numero
                            resultado = numero
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botones de acción
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                listaNumeros = (0..8 step 2).map { "No $it" }
                selectedItem = ""
                resultado = ""
            }) {
                Text("Pares")
            }

            Button(onClick = {
                listaNumeros = (1..9 step 2).map { "No $it" }
                selectedItem = ""
                resultado = ""
            }) {
                Text("Impares")
            }

            Button(onClick = {
                listaNumeros = emptyList()
                selectedItem = ""
                resultado = ""
            }) {
                Text("Vaciar")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Resultado
        Text(
            text = resultado,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }

}
