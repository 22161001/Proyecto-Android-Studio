package com.example.proyecttap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.activity.ComponentActivity as AndroidComponentActivity

class Ejercicio2Activity : AndroidComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PantallaEjercicio2()
        }
    }
}

@Composable
fun PantallaEjercicio2() {
    val context = LocalContext.current  // <-- Aquí obtenemos el contexto

    var colorSeleccionado by remember { mutableStateOf("") }
    var resultado by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Colores", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(8.dp))

        RadioButtonConEtiqueta("Rojo", colorSeleccionado) { colorSeleccionado = "Rojo" }
        RadioButtonConEtiqueta("Verde", colorSeleccionado) { colorSeleccionado = "Verde" }
        RadioButtonConEtiqueta("Azul", colorSeleccionado) { colorSeleccionado = "Azul" }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            resultado = "Color elegido: $colorSeleccionado"
        }) {
            Text("Aceptar")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = resultado,
            modifier = Modifier
                .border(1.dp, Color.Black)
                .padding(8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Botón para regresar al menú principal (cerrar esta actividad)
        Button(onClick = {
            (context as? AndroidComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}

@Composable
fun RadioButtonConEtiqueta(texto: String, seleccionado: String, onSelect: () -> Unit) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        RadioButton(
            selected = seleccionado == texto,
            onClick = onSelect
        )
        Text(text = texto)
    }
}

