package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Ejercicio7Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PrecioTotalApp()
        }
    }
}

@Composable
fun PrecioTotalApp() {
    val context = LocalContext.current
    var precioBaseText by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }

    var instalacion by remember { mutableStateOf(false) }
    var formacion by remember { mutableStateOf(false) }
    var alimentacionBD by remember { mutableStateOf(false) }

    val precioInstalacion = 40.0
    val precioFormacion = 200.0
    val precioAlimentacionBD = 200.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Precio Base")

        TextField(
            value = precioBaseText,
            onValueChange = { precioBaseText = it },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
            modifier = Modifier.border(1.dp, Color.Gray),
            placeholder = { Text("Introduce precio base") }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleButton("Instalación", instalacion) { instalacion = !instalacion }
            Text("($precioInstalacion)")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleButton("Formación", formacion) { formacion = !formacion }
            Text("($precioFormacion)")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToggleButton("Alimentación BD", alimentacionBD) { alimentacionBD = !alimentacionBD }
            Text("($precioAlimentacionBD)")
        }

        Button(onClick = {

            val base = precioBaseText.toDoubleOrNull()
            if (base != null) {
                var totalCalc = base
                if (instalacion) totalCalc += precioInstalacion
                if (formacion) totalCalc += precioFormacion
                if (alimentacionBD) totalCalc += precioAlimentacionBD
                total = "%.2f $".format(totalCalc)
            } else {
                total = "Precio inválido"
            }
        }) {
            Text("Calcular")
        }

        Text(
            text = "Total: $total",
            fontSize = 20.sp,
            color = Color.DarkGray
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}

@Composable
fun ToggleButton(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Button(

        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) Color.Green else Color.LightGray
        )
    ) {
        Text(label)

    }

}

