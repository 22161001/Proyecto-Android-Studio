package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio10Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Ejercicio10VerticalApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio10VerticalApp() {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ejercicio 10 ") }
            )
        },
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                Button(
                    onClick = { showToast(context, "Activaste el botón uno") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = "Uno",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Uno")
                }


                Button(
                    onClick = { showToast(context, "Activaste el botón dos") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Dos")
                }


                Button(
                    onClick = { showToast(context, "Activaste el botón tres") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Tres")
                }


                Button(
                    onClick = { showToast(context, "Activaste el botón cuatro") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cuatro")
                }
                Spacer(modifier = Modifier.height(24.dp))

                Button(onClick = {
                    (context as? ComponentActivity)?.finish()
                }) {
                    Text("Regresar al menú")
                }
            }
        }
    )
}

fun showToast(context: android.content.Context, message: String) {
    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
}