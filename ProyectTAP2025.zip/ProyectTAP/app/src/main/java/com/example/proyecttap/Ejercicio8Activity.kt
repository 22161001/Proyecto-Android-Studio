package com.example.proyecttap

import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.unit.dp
import com.example.proyecttap.ui.theme.ProyectTAPTheme

class Ejercicio8Activity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectTAPTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Ejercicio8Screen()
                }
            }
        }
    }
}

@Composable
fun Ejercicio8Screen() {
    val context = LocalContext.current
    var sliderValue by remember { mutableStateOf(400f) }
    val minValue = 100f
    val maxValue = 500f

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Slider vertical
        Slider(
            value = sliderValue,
            onValueChange = { newValue -> sliderValue = newValue }, // Corrección aquí
            valueRange = minValue..maxValue,
            steps = 39,
            modifier = Modifier
                .height(300.dp)
                .rotate(270f)
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Mostrar el valor actual
        Text(
            text = "El valor es: ${sliderValue.toInt()}",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .wrapContentWidth(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            (context as? ComponentActivity)?.finish()
        }) {
            Text("Regresar al menú")
        }
    }
}